import Link from 'next/link'
import MemoryDetailClient from '@/components/memory-detail-client'

// All memories data
const memories: Record<string, any> = {
  'beginning': {
    id: 'beginning',
    date: 'May 15, 2023',
    title: 'The Beginning',
    description: 'Coffee on a Sunday morning. The way you laughed when I said something stupid. I knew right then.',
    emoji: '☕',
    fullStory: 'That Sunday morning coffee became the beginning of everything. You arrived with that beautiful smile, wearing that old sweater I loved. We sat at that little cafe by the window, and time seemed to stop. The world around us faded away—there was just us, the warm coffee, and the feeling that something extraordinary was starting. Every word you said, I memorized. Every laugh, every gesture, every moment. I knew in that instant that my life was about to change forever. This wasn\'t just a date; it was the moment I fell in love.',
    photos: ['coffee-morning.jpg', 'first-smile.jpg', 'that-sweater.jpg'],
  },
  'fireworks': {
    id: 'fireworks',
    date: 'July 4, 2023',
    title: 'Fireworks',
    description: 'We watched them from your apartment roof. You held my hand the entire time.',
    emoji: '✨',
    fullStory: 'Independence Day felt different with you. We snuck onto your apartment roof with blankets and snacks, watching the city light up below us. The fireworks reflected in your eyes, and I couldn\'t look away from you. When the explosions started, you grabbed my hand without hesitation. In that moment, surrounded by light and noise, the only thing I could feel was your hand in mine. It was perfect. Simple and pure. I realized that night that the most beautiful explosions of color were nothing compared to the spark I felt when you were beside me.',
    photos: ['rooftop-night.jpg', 'hand-in-hand.jpg', 'fireworks-sky.jpg'],
  },
  'first-trip': {
    id: 'first-trip',
    date: 'September 12, 2023',
    title: 'First Trip',
    description: 'We got lost trying to find that bookstore. Best wrong turn ever taken.',
    emoji: '🗺️',
    fullStory: 'We were supposed to meet the travel writer at that famous bookstore downtown. But we took a wrong turn and ended up in this hidden alley with cobblestone streets and vintage shops. Instead of being frustrated, we laughed. We wandered for hours, discovering tiny cafes, street art, and each other in deeper ways. We talked about our dreams, our fears, our crazy ideas for the future. Getting lost wasn\'t a failure—it was a gift. It taught us that sometimes the best moments come from unplanned detours. That day, I realized that being lost with you was better than being found with anyone else.',
    photos: ['cobblestone-alley.jpg', 'bookstore-laugh.jpg', 'lost-together.jpg'],
  },
  'winter': {
    id: 'winter',
    date: 'December 25, 2023',
    title: 'Winter Wonderland',
    description: 'Snow falling while we sat in comfortable silence. No words needed.',
    emoji: '❄️',
    fullStory: 'Christmas morning brought fresh snow, and we sat by the window wrapped in blankets, watching the world transform. We didn\'t need to speak. Sometimes the deepest connections are in silence—in the comfortable quiet that only comes when you\'ve found someone who truly understands you. The snow kept falling, and we stayed there for hours, just being. Your head on my shoulder, my hand in yours. No gifts could compare to that moment. That\'s when I knew—love isn\'t always about grand gestures. Sometimes it\'s about snow, silence, and the person sitting beside you.',
    photos: ['snowy-window.jpg', 'blanket-together.jpg', 'winter-peace.jpg'],
  },
  'vulnerability': {
    id: 'vulnerability',
    date: 'February 14, 2024',
    title: 'Vulnerability',
    description: 'You asked me about my fears. I told you everything. You didn\'t run.',
    emoji: '💔',
    fullStory: 'Valentine\'s Day, and instead of dinner and flowers, you asked me something that changed everything. You asked about my deepest fears. And I told you. I told you about the times I felt broken, the dreams I was afraid to chase, the insecurities that kept me up at night. I showed you my scars. And you didn\'t run. You held my hand and you said, "These scars prove you\'re a survivor. They\'re beautiful because they\'re yours." That night, I understood what real love was. It wasn\'t about perfect moments—it was about being truly seen and chosen anyway.',
    photos: ['valentine-conversation.jpg', 'tears-and-comfort.jpg', 'hand-hold-dark.jpg'],
  },
  'distance': {
    id: 'distance',
    date: 'April 8, 2024',
    title: 'The Distance',
    description: 'The first time we had to say goodbye. It hurt more than I expected.',
    emoji: '🌙',
    fullStory: 'Reality hit when the relocation came. We held each other at the airport, and I couldn\'t let go. The distance wasn\'t just miles—it was the realization that love alone might not be enough. We promised we\'d make it work, but standing at that gate, watching you disappear, I felt something shift. The universe was testing us, and I wasn\'t sure we\'d pass. That goodbye at the airport became the first crack in what we built. It taught me that sometimes the cruelest thing about love is timing.',
    photos: ['airport-goodbye.jpg', 'embrace-last.jpg', 'empty-gate.jpg'],
  },
  'growing-apart': {
    id: 'growing-apart',
    date: 'June 20, 2024',
    title: 'Growing Apart',
    description: 'We were still together, but something was shifting. I felt it too.',
    emoji: '🌊',
    fullStory: 'The hardest part wasn\'t the day we broke up—it was the slow fade. We were still together, still trying, but we were becoming strangers. Your voice on FaceTime felt distant even though I could hear it perfectly. We ran out of things to say. The connection that once felt electric was becoming routine. We were both feeling it, circling each other carefully, hoping the other would find a way to fix it. But sometimes love isn\'t broken—it\'s just changing. And we were too scared to admit that maybe it was changing into something it couldn\'t be anymore.',
    photos: ['late-night-call.jpg', 'empty-texts.jpg', 'distance-portrait.jpg'],
  },
  'the-break': {
    id: 'the-break',
    date: 'August 15, 2024',
    title: 'The Break',
    description: 'It wasn\'t dramatic. Just... necessary. Like seasons changing.',
    emoji: '🍂',
    fullStory: 'When we finally said the words, it didn\'t feel like a fight or a tragedy. It felt like autumn—natural, necessary, inevitable. We sat across from each other and said, "I love you, but this isn\'t working." There was no yelling, no blame. Just two people who loved each other deeply but weren\'t enough for each other at this moment. We cried, but they were gentle tears. The tears you cry when something beautiful ends. We held each other one last time and said goodbye not with anger, but with gratitude for everything we\'d been to each other. It was the most loving breakup I\'ve ever experienced.',
    photos: ['final-coffee.jpg', 'goodbye-embrace.jpg', 'autumn-leaves.jpg'],
  },
}

interface PageProps {
  params: Promise<{ id: string }>
}

export default async function MemoryDetailPage({ params }: PageProps) {
  const { id } = await params
  const memory = memories[id]

  if (!memory) {
    return (
      <div className="min-h-screen bg-background text-foreground flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-4xl font-bold mb-4">Memory not found</h1>
          <Link href="/" className="text-accent hover:underline">
            Return to home
          </Link>
        </div>
      </div>
    )
  }

  return <MemoryDetailClient memory={memory} />
}
