'use client'

import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import Image from 'next/image'
import Particles from '@/components/particles'

interface GalleryImage {
  id: number
  title: string
  date: string
  size?: 'small' | 'medium' | 'large'
}

const galleryImages: GalleryImage[] = [
  { id: 1, title: 'First Coffee', date: 'May 2023', size: 'large' },
  { id: 2, title: 'Sunset Walk', date: 'June 2023', size: 'small' },
  { id: 3, title: 'Rainy Days', date: 'July 2023', size: 'medium' },
  { id: 4, title: 'Your Smile', date: 'August 2023', size: 'small' },
  { id: 5, title: 'Winter Together', date: 'December 2023', size: 'large' },
  { id: 6, title: 'Quiet Moments', date: 'January 2024', size: 'medium' },
  { id: 7, title: 'Adventures', date: 'February 2024', size: 'small' },
  { id: 8, title: 'Last Sunset', date: 'August 2024', size: 'large' },
]

const getGridPosition = (index: number) => {
  const sizes = ['small', 'large', 'medium', 'small', 'large', 'medium', 'small', 'large']
  const size = sizes[index % sizes.length]

  switch (size) {
    case 'large':
      return 'col-span-2 row-span-2'
    case 'medium':
      return 'col-span-1 row-span-1'
    default:
      return 'col-span-1 row-span-1'
  }
}

export default function GalleryPage() {
  const [selectedId, setSelectedId] = useState<number | null>(null)
  const [selectedImage, setSelectedImage] = useState<GalleryImage | null>(null)

  const handleImageClick = (image: GalleryImage) => {
    setSelectedId(image.id)
    setSelectedImage(image)
  }

  const handleClose = () => {
    setSelectedId(null)
    setSelectedImage(null)
  }

  return (
    <main className="min-h-screen relative overflow-hidden pt-32 pb-20">
      <Particles />

      <div className="relative z-10 max-w-7xl mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="mb-16 text-center"
        >
          <h1 className="text-5xl md:text-6xl font-bold mb-6">Photo Gallery</h1>
          <p className="text-lg text-foreground/60">
            Moments captured in time. Click any photo to view larger.
          </p>
        </motion.div>

        {/* Masonry Grid */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12"
        >
          {galleryImages.map((image, index) => (
            <motion.div
              key={image.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              viewport={{ once: true }}
              className={`${getGridPosition(index)} cursor-pointer group relative overflow-hidden rounded-lg border border-border/50 hover:border-accent/50 transition-all duration-300`}
              onClick={() => handleImageClick(image)}
            >
              <div className="w-full h-full min-h-80 md:min-h-96 bg-gradient-to-br from-accent/20 to-primary/20 flex items-center justify-center relative overflow-hidden">
                {/* Placeholder with emoji */}
                <div className="absolute inset-0 flex items-center justify-center text-6xl md:text-7xl opacity-50 group-hover:opacity-70 transition-opacity duration-300">
                  {String.fromCharCode(128512 + (image.id % 10))}
                </div>

                {/* Overlay on hover */}
                <motion.div
                  initial={{ opacity: 0 }}
                  whileHover={{ opacity: 1 }}
                  transition={{ duration: 0.3 }}
                  className="absolute inset-0 bg-black/50 backdrop-blur-sm flex flex-col items-center justify-center"
                >
                  <h3 className="text-xl font-semibold text-white mb-2">{image.title}</h3>
                  <p className="text-sm text-white/80">{image.date}</p>
                </motion.div>
              </div>
            </motion.div>
          ))}
        </motion.div>

        {/* Modal for expanded view */}
        <AnimatePresence>
          {selectedId && selectedImage && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={handleClose}
              className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            >
              <motion.div
                initial={{ scale: 0.9, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.9, opacity: 0 }}
                onClick={(e) => e.stopPropagation()}
                className="relative bg-card border border-border rounded-xl max-w-2xl w-full"
              >
                {/* Close button */}
                <button
                  onClick={handleClose}
                  className="absolute top-4 right-4 z-10 w-10 h-10 bg-background/80 backdrop-blur-sm border border-border rounded-full flex items-center justify-center hover:bg-background transition-all"
                  aria-label="Close image"
                >
                  <svg
                    className="w-6 h-6"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M6 18L18 6M6 6l12 12"
                    />
                  </svg>
                </button>

                {/* Image placeholder */}
                <div className="w-full aspect-square md:aspect-video bg-gradient-to-br from-accent/30 to-primary/30 flex items-center justify-center text-9xl">
                  {String.fromCharCode(128512 + (selectedImage.id % 10))}
                </div>

                {/* Image info */}
                <div className="p-8">
                  <h2 className="text-3xl font-bold mb-2">{selectedImage.title}</h2>
                  <p className="text-lg text-foreground/60 mb-6">{selectedImage.date}</p>
                  <p className="text-foreground/70 leading-relaxed">
                    Every photograph tells a story. This moment, captured in time, is ours to keep. It reminds us of who we were, and how we loved.
                  </p>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </main>
  )
}
