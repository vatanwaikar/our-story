'use client'

import { useEffect, useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import Link from 'next/link'
import Image from 'next/image'
import Particles from '@/components/particles'

// Memories data
const memories = [
  {
    id: 'beginning',
    date: 'May 15, 2023',
    title: 'The Beginning',
    description: 'Coffee on a Sunday morning. The way you laughed when I said something stupid. I knew right then.',
    emoji: '☕',
    fullStory: 'That Sunday morning coffee became the beginning of everything. You arrived with that beautiful smile, wearing that old sweater I loved. We sat at that little cafe by the window, and time seemed to stop. The world around us faded away—there was just us, the warm coffee, and the feeling that something extraordinary was starting. Every word you said, I memorized. Every laugh, every gesture, every moment. I knew in that instant that my life was about to change forever. This wasn\'t just a date; it was the moment I fell in love.',
    photos: ['coffee-morning.jpg', 'first-smile.jpg', 'that-sweater.jpg'],
  },
  {
    id: 'fireworks',
    date: 'July 4, 2023',
    title: 'Fireworks',
    description: 'We watched them from your apartment roof. You held my hand the entire time.',
    emoji: '✨',
    fullStory: 'Independence Day felt different with you. We snuck onto your apartment roof with blankets and snacks, watching the city light up below us. The fireworks reflected in your eyes, and I couldn\'t look away from you. When the explosions started, you grabbed my hand without hesitation. In that moment, surrounded by light and noise, the only thing I could feel was your hand in mine. It was perfect. Simple and pure. I realized that night that the most beautiful explosions of color were nothing compared to the spark I felt when you were beside me.',
    photos: ['rooftop-night.jpg', 'hand-in-hand.jpg', 'fireworks-sky.jpg'],
  },
  {
    id: 'first-trip',
    date: 'September 12, 2023',
    title: 'First Trip',
    description: 'We got lost trying to find that bookstore. Best wrong turn ever taken.',
    emoji: '🗺️',
    fullStory: 'We were supposed to meet the travel writer at that famous bookstore downtown. But we took a wrong turn and ended up in this hidden alley with cobblestone streets and vintage shops. Instead of being frustrated, we laughed. We wandered for hours, discovering tiny cafes, street art, and each other in deeper ways. We talked about our dreams, our fears, our crazy ideas for the future. Getting lost wasn\'t a failure—it was a gift. It taught us that sometimes the best moments come from unplanned detours. That day, I realized that being lost with you was better than being found with anyone else.',
    photos: ['cobblestone-alley.jpg', 'bookstore-laugh.jpg', 'lost-together.jpg'],
  },
  {
    id: 'winter',
    date: 'December 25, 2023',
    title: 'Winter Wonderland',
    description: 'Snow falling while we sat in comfortable silence. No words needed.',
    emoji: '❄️',
    fullStory: 'Christmas morning brought fresh snow, and we sat by the window wrapped in blankets, watching the world transform. We didn\'t need to speak. Sometimes the deepest connections are in silence—in the comfortable quiet that only comes when you\'ve found someone who truly understands you. The snow kept falling, and we stayed there for hours, just being. Your head on my shoulder, my hand in yours. No gifts could compare to that moment. That\'s when I knew—love isn\'t always about grand gestures. Sometimes it\'s about snow, silence, and the person sitting beside you.',
    photos: ['snowy-window.jpg', 'blanket-together.jpg', 'winter-peace.jpg'],
  },
  {
    id: 'vulnerability',
    date: 'February 14, 2024',
    title: 'Vulnerability',
    description: 'You asked me about my fears. I told you everything. You didn\'t run.',
    emoji: '💔',
    fullStory: 'Valentine\'s Day, and instead of dinner and flowers, you asked me something that changed everything. You asked about my deepest fears. And I told you. I told you about the times I felt broken, the dreams I was afraid to chase, the insecurities that kept me up at night. I showed you my scars. And you didn\'t run. You held my hand and you said, "These scars prove you\'re a survivor. They\'re beautiful because they\'re yours." That night, I understood what real love was. It wasn\'t about perfect moments—it was about being truly seen and chosen anyway.',
    photos: ['valentine-conversation.jpg', 'tears-and-comfort.jpg', 'hand-hold-dark.jpg'],
  },
  {
    id: 'distance',
    date: 'April 8, 2024',
    title: 'The Distance',
    description: 'The first time we had to say goodbye. It hurt more than I expected.',
    emoji: '🌙',
    fullStory: 'Reality hit when the relocation came. We held each other at the airport, and I couldn\'t let go. The distance wasn\'t just miles—it was the realization that love alone might not be enough. We promised we\'d make it work, but standing at that gate, watching you disappear, I felt something shift. The universe was testing us, and I wasn\'t sure we\'d pass. That goodbye at the airport became the first crack in what we built. It taught me that sometimes the cruelest thing about love is timing.',
    photos: ['airport-goodbye.jpg', 'embrace-last.jpg', 'empty-gate.jpg'],
  },
  {
    id: 'growing-apart',
    date: 'June 20, 2024',
    title: 'Growing Apart',
    description: 'We were still together, but something was shifting. I felt it too.',
    emoji: '🌊',
    fullStory: 'The hardest part wasn\'t the day we broke up—it was the slow fade. We were still together, still trying, but we were becoming strangers. Your voice on FaceTime felt distant even though I could hear it perfectly. We ran out of things to say. The connection that once felt electric was becoming routine. We were both feeling it, circling each other carefully, hoping the other would find a way to fix it. But sometimes love isn\'t broken—it\'s just changing. And we were too scared to admit that maybe it was changing into something it couldn\'t be anymore.',
    photos: ['late-night-call.jpg', 'empty-texts.jpg', 'distance-portrait.jpg'],
  },
  {
    id: 'the-break',
    date: 'August 15, 2024',
    title: 'The Break',
    description: 'It wasn\'t dramatic. Just... necessary. Like seasons changing.',
    emoji: '🍂',
    fullStory: 'When we finally said the words, it didn\'t feel like a fight or a tragedy. It felt like autumn—natural, necessary, inevitable. We sat across from each other and said, "I love you, but this isn\'t working." There was no yelling, no blame. Just two people who loved each other deeply but weren\'t enough for each other at this moment. We cried, but they were gentle tears. The tears you cry when something beautiful ends. We held each other one last time and said goodbye not with anger, but with gratitude for everything we\'d been to each other. It was the most loving breakup I\'ve ever experienced.',
    photos: ['final-coffee.jpg', 'goodbye-embrace.jpg', 'autumn-leaves.jpg'],
  },
]

// Story sections
const storySection = [
  {
    id: 'distance',
    title: 'The Distance',
    subtitle: 'When miles became more than geography',
    content:
      'At first, we thought we could make it work. Long nights on FaceTime, endless messages, weekend visits. We were determined. We were in love. But slowly, the distance did what distance does—it stretched everything. Not just time zones, but moments. The little laughs we couldn\'t share. The random conversations that made us us. We tried to hold on, but love needs presence too.',
    emoji: '🌍',
  },
  {
    id: 'second-chances',
    title: 'Second Chances',
    subtitle: 'Because sometimes goodbye isn\'t the end',
    content:
      'We didn\'t make it the first time. But we came back. Not because we didn\'t learn. But because we couldn\'t imagine not trying. That second chapter was different—more honest. We knew what we were up against. We negotiated. We compromised. We believed harder. And for a while, it felt like we had finally figured it out. But some chapters don\'t get the ending we want.',
    emoji: '🔄',
  },
  {
    id: 'learnings',
    title: 'What We Learned',
    subtitle: 'The wisdom that comes from goodbye',
    content:
      'You can love someone with all your heart and still not be right for them at the right time. You can try everything and still lose. And that\'s not failure—that\'s life. We learned that love isn\'t always about forever. Sometimes it\'s about being there when someone needs you most. Sometimes it\'s about knowing when to let go. We learned that the measure of a relationship isn\'t whether it lasted, but what it taught us. I learned to love better because of you. More honestly. More bravely. More myself.',
    emoji: '✨',
  },
  {
    id: 'future',
    title: 'If We Start Again',
    subtitle: 'The story we never got to live, but should remember',
    content:
      'In another timeline, we make different choices. We say the hard things sooner. We fight harder for what we want. We choose each other, again and again. But in this timeline, we have something different. We have the memory of what we built. We have the knowledge that for a moment in time, we were each other\'s person. And that means something. That will always mean something.',
    emoji: '🌟',
  },
]

// Gallery images
const galleryImages = [
  { id: 1, title: 'First Coffee', date: 'May 2023', size: 'large' },
  { id: 2, title: 'Sunset Walk', date: 'June 2023', size: 'small' },
  { id: 3, title: 'Rainy Days', date: 'July 2023', size: 'medium' },
  { id: 4, title: 'Your Smile', date: 'August 2023', size: 'small' },
  { id: 5, title: 'Winter Together', date: 'December 2023', size: 'large' },
  { id: 6, title: 'Quiet Moments', date: 'January 2024', size: 'medium' },
  { id: 7, title: 'Adventures', date: 'February 2024', size: 'small' },
  { id: 8, title: 'Last Sunset', date: 'August 2024', size: 'large' },
]

const getGridPosition = (index: number) => {
  const sizes = ['small', 'large', 'medium', 'small', 'large', 'medium', 'small', 'large']
  const size = sizes[index % sizes.length]
  
  switch (size) {
    case 'large':
      return 'col-span-2 row-span-2'
    case 'medium':
      return 'col-span-1 row-span-1'
    default:
      return 'col-span-1 row-span-1'
  }
}

// Animation variants
const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.2,
    },
  },
}

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.6 },
  },
}

const storyVariants = {
  hidden: { opacity: 0, y: 40 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.8 },
  },
}

export default function Home() {
  const [mounted, setMounted] = useState(false)
  const [selectedImageId, setSelectedImageId] = useState<number | null>(null)

  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) return null

  const selectedImage = galleryImages.find(img => img.id === selectedImageId)

  return (
    <main className="min-h-screen relative overflow-hidden">
      <Particles />

      {/* HERO SECTION */}
      <div className="relative z-10 h-screen flex flex-col items-center justify-center px-4 text-center pt-20">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="mb-8"
        >
          <h1 className="text-5xl md:text-7xl font-bold mb-6 leading-tight">
            <span className="text-foreground">Our</span>{' '}
            <span className="bg-gradient-to-r from-accent via-primary to-accent bg-clip-text text-transparent">
              Love Story
            </span>
          </h1>
        </motion.div>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="text-lg md:text-xl text-foreground/70 max-w-2xl mb-12 leading-relaxed"
        >
          A cinematic journey through memories, moments, and what we learned together. A story of distance, second chances, and hope.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.6 }}
          className="flex flex-col sm:flex-row gap-4"
        >
          <a
            href="#begin-journey"
            className="px-8 py-3 bg-accent text-accent-foreground rounded-lg font-semibold hover:shadow-lg hover:shadow-accent/30 transition-all duration-300 transform hover:scale-105"
          >
            Begin the Journey
          </a>
          <a
            href="#our-story"
            className="px-8 py-3 border border-accent text-accent rounded-lg font-semibold hover:bg-accent/10 transition-all duration-300"
          >
            Our Story
          </a>
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1, delay: 1 }}
          className="absolute bottom-10 left-1/2 transform -translate-x-1/2 animate-float"
        >
          <div className="w-6 h-10 border-2 border-accent/50 rounded-full flex items-center justify-center">
            <div className="w-1 h-2 bg-accent/50 rounded-full animate-pulse" />
          </div>
        </motion.div>
      </div>

      {/* BEGIN THE JOURNEY SECTION - Memories */}
      <section id="begin-journey" className="relative z-10 min-h-screen flex items-center py-24 px-4">
        <div className="max-w-4xl mx-auto w-full">
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="mb-16 text-center"
          >
            <h2 className="text-5xl md:text-6xl font-bold mb-6">Begin the Journey</h2>
            <p className="text-lg text-foreground/60">
              A timeline of moments that shaped us. Both the beautiful and the bittersweet.
            </p>
          </motion.div>

          <motion.div
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: '-100px' }}
            className="space-y-8"
          >
            {memories.map((memory, index) => (
              <motion.div
                key={index}
                variants={itemVariants}
                className="relative pl-8 md:pl-16"
              >
                <div className="absolute left-0 top-0 w-px h-full bg-gradient-to-b from-accent/50 to-accent/10" />
                <div className="absolute left-[-8px] top-4 w-4 h-4 rounded-full bg-accent" />

                <Link href={`/memory/${memory.id}`}>
                  <div className="bg-card/40 backdrop-blur-sm border border-border rounded-lg overflow-hidden hover:border-accent/50 hover:bg-card/60 transition-all duration-300 cursor-pointer group">
                    {/* Thumbnail image */}
                    <div className="relative h-40 overflow-hidden bg-gradient-to-br from-accent/20 to-primary/20">
                      <Image
                        src={`/memories/${memory.photos[0]}`}
                        alt={memory.title}
                        fill
                        className="object-cover group-hover:scale-105 transition-transform duration-300"
                        sizes="(max-width: 768px) 100vw, 50vw"
                      />
                      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-background/20 pointer-events-none" />
                    </div>
                    
                    {/* Content */}
                    <div className="p-6">
                      <div className="flex items-start gap-4 mb-3">
                        <span className="text-3xl group-hover:scale-110 transition-transform duration-300">{memory.emoji}</span>
                        <div className="flex-1">
                          <time className="text-sm font-medium text-accent">{memory.date}</time>
                          <h3 className="text-xl font-semibold mt-1 group-hover:text-accent transition-colors duration-300">{memory.title}</h3>
                        </div>
                      </div>
                      <p className="text-foreground/70 leading-relaxed mb-4">{memory.description}</p>
                      <div className="mt-4 text-sm text-accent/70 group-hover:text-accent transition-colors duration-300">
                        Click to read more →
                      </div>
                    </div>
                  </div>
                </Link>
              </motion.div>
            ))}
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="mt-20 text-center"
          >
            <p className="text-lg text-foreground/60 italic">
              Each memory is a thread in the tapestry of what we were. And what we learned.
            </p>
          </motion.div>
        </div>
      </section>

      {/* OUR STORY SECTION */}
      <section id="our-story" className="relative z-10 min-h-screen flex items-center py-24 px-4">
        <div className="max-w-4xl mx-auto w-full">
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="mb-20 text-center"
          >
            <h2 className="text-5xl md:text-6xl font-bold mb-6">Our Story</h2>
            <p className="text-lg text-foreground/60">
              Four chapters that shaped who we became.
            </p>
          </motion.div>

          <motion.div
            className="space-y-20"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: '-100px' }}
            variants={{
              visible: {
                transition: {
                  staggerChildren: 0.3,
                },
              },
            }}
          >
            {storySection.map((section, index) => (
              <motion.div
                key={section.id}
                variants={storyVariants}
                id={section.id}
                className="scroll-mt-24"
              >
                <div
                  className={`flex flex-col ${
                    index % 2 === 0 ? 'lg:flex-row' : 'lg:flex-row-reverse'
                  } gap-12 items-start`}
                >
                  <div className="flex-1 min-h-96 rounded-xl overflow-hidden border border-border/50 bg-gradient-to-br from-accent/20 to-primary/20 flex items-center justify-center">
                    <motion.div
                      initial={{ scale: 0.8, opacity: 0 }}
                      whileInView={{ scale: 1, opacity: 1 }}
                      transition={{ duration: 0.8 }}
                      className="text-8xl"
                    >
                      {section.emoji}
                    </motion.div>
                  </div>

                  <div className="flex-1">
                    <motion.h3
                      initial={{ opacity: 0, y: 10 }}
                      whileInView={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.6 }}
                      viewport={{ once: true }}
                      className="text-4xl md:text-5xl font-bold mb-3"
                    >
                      {section.title}
                    </motion.h3>
                    <motion.p
                      initial={{ opacity: 0, y: 10 }}
                      whileInView={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.6, delay: 0.1 }}
                      viewport={{ once: true }}
                      className="text-lg text-accent font-semibold mb-6"
                    >
                      {section.subtitle}
                    </motion.p>
                    <motion.p
                      initial={{ opacity: 0, y: 10 }}
                      whileInView={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.6, delay: 0.2 }}
                      viewport={{ once: true }}
                      className="text-lg leading-relaxed text-foreground/80"
                    >
                      {section.content}
                    </motion.p>
                  </div>
                </div>
              </motion.div>
            ))}
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="mt-24 text-center bg-card/30 backdrop-blur-sm border border-border rounded-xl p-12"
          >
            <p className="text-xl text-foreground/70 leading-relaxed mb-4">
              &quot;In the end, it wasn&apos;t about whether we made it. It was about the fact that we tried.&quot;
            </p>
            <p className="text-lg text-accent font-semibold">— Us</p>
          </motion.div>
        </div>
      </section>

      {/* GALLERY SECTION */}
      <section className="relative z-10 min-h-screen flex items-center py-24 px-4">
        <div className="max-w-7xl mx-auto w-full">
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="mb-16 text-center"
          >
            <h2 className="text-5xl md:text-6xl font-bold mb-6">Photo Gallery</h2>
            <p className="text-lg text-foreground/60">
              Moments captured in time. Click any photo to view larger.
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            viewport={{ once: true }}
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12"
          >
            {galleryImages.map((image, index) => (
              <motion.div
                key={image.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                viewport={{ once: true }}
                className={`${getGridPosition(index)} cursor-pointer group relative overflow-hidden rounded-lg border border-border/50 hover:border-accent/50 transition-all duration-300`}
                onClick={() => setSelectedImageId(image.id)}
              >
                <div className="w-full h-full min-h-80 md:min-h-96 bg-gradient-to-br from-accent/20 to-primary/20 flex items-center justify-center relative overflow-hidden">
                  <div className="absolute inset-0 flex items-center justify-center text-6xl md:text-7xl opacity-50 group-hover:opacity-70 transition-opacity duration-300">
                    {String.fromCharCode(128512 + (image.id % 10))}
                  </div>

                  <motion.div
                    initial={{ opacity: 0 }}
                    whileHover={{ opacity: 1 }}
                    transition={{ duration: 0.3 }}
                    className="absolute inset-0 bg-black/50 backdrop-blur-sm flex flex-col items-center justify-center"
                  >
                    <h3 className="text-xl font-semibold text-white mb-2">{image.title}</h3>
                    <p className="text-sm text-white/80">{image.date}</p>
                  </motion.div>
                </div>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* CLOSING SECTION */}
      <div className="relative z-10 min-h-screen flex items-center justify-center px-4 py-24">
        <motion.div
          initial={{ opacity: 0, y: 60 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 1 }}
          viewport={{ once: true }}
          className="w-full max-w-2xl"
        >
          <div className="backdrop-blur-md bg-card/40 border border-accent/20 rounded-2xl p-12 md:p-16 shadow-2xl relative overflow-hidden group">
            <div className="absolute inset-0 bg-gradient-to-br from-accent/5 via-transparent to-primary/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
            
            <div className="relative z-10 text-center">
              <motion.p
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
                transition={{ duration: 0.8, delay: 0.2 }}
                viewport={{ once: true }}
                className="text-sm md:text-base text-foreground/60 italic mb-12 leading-relaxed animate-pulse"
              >
                If you&apos;ve seen everything till here…<br />
                there&apos;s just one last thing I want you to read.
              </motion.p>

              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.8, delay: 0.4 }}
                viewport={{ once: true }}
              >
                <Link
                  href="/last-message"
                  className="inline-block px-12 py-4 rounded-full font-semibold text-lg relative group/btn overflow-hidden"
                >
                  <div className="absolute inset-0 bg-gradient-to-r from-accent via-primary to-accent opacity-70 group-hover/btn:opacity-100 transition-opacity duration-300 rounded-full blur" />
                  
                  <div className="relative bg-background/80 group-hover/btn:bg-background/60 transition-colors duration-300 rounded-full px-12 py-4 flex items-center justify-center gap-3">
                    <span className="text-foreground">One Last Truth</span>
                    
                    <motion.div
                      initial={{ x: '-100%' }}
                      whileHover={{ x: '100%' }}
                      transition={{ duration: 0.6 }}
                      className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent rounded-full pointer-events-none"
                    />
                  </div>

                  <div className="absolute inset-0 opacity-0 group-hover/btn:opacity-100 transition-opacity duration-300 rounded-full shadow-lg shadow-accent/50" />
                </Link>
              </motion.div>
            </div>
          </div>
        </motion.div>
      </div>

      {/* GALLERY MODAL */}
      <AnimatePresence>
        {selectedImageId && selectedImage && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setSelectedImageId(null)}
            className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4"
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="relative bg-card border border-border rounded-xl max-w-2xl w-full"
            >
              <button
                onClick={() => setSelectedImageId(null)}
                className="absolute top-4 right-4 z-10 w-10 h-10 bg-background/80 backdrop-blur-sm border border-border rounded-full flex items-center justify-center hover:bg-background transition-all"
                aria-label="Close image"
              >
                <svg
                  className="w-6 h-6"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M6 18L18 6M6 6l12 12"
                  />
                </svg>
              </button>

              <div className="w-full aspect-square md:aspect-video bg-gradient-to-br from-accent/30 to-primary/30 flex items-center justify-center text-9xl">
                {String.fromCharCode(128512 + (selectedImage.id % 10))}
              </div>

              <div className="p-8">
                <h2 className="text-3xl font-bold mb-2">{selectedImage.title}</h2>
                <p className="text-lg text-foreground/60 mb-6">{selectedImage.date}</p>
                <p className="text-foreground/70 leading-relaxed">
                  Every photograph tells a story. This moment, captured in time, is ours to keep. It reminds us of who we were, and how we loved.
                </p>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </main>
  )
}
